#!/bin/bash
# Quick LGR status check

echo "=== LGR STATUS CHECK ==="
echo ""

echo "1. LGR Containers:"
docker ps -a | grep -E "NAMES|lgr_wordpress|lgr_mariadb" | grep -v "lgr_engine\|lgr-"
echo ""

echo "2. Database check:"
docker exec lgr_mariadb mysql -u root -pLGRl2sSSb2026 -e "USE leadsgrowrevenue_wp; SHOW TABLES;" 2>/dev/null || echo "Cannot access database"
echo ""

echo "3. WordPress files:"
ls -lh /mnt/HC_Volume_104274212/lgr-services/wordpress/leadsgrowrevenue/ 2>/dev/null | head -5 || echo "WordPress files not found"
echo ""

echo "4. Backup files:"
find /mnt/HC_Volume_104274212/backups -name "*lgr*" -type d 2>/dev/null | head -5 || echo "No backup directories found"
