#!/bin/bash
set -e
echo "=========================================="
echo "Cleanup: Removing Broken WordPress"
echo "=========================================="
CADDYFILE="/opt/southsuburbs/Caddyfile"
echo "1. Backing up Caddyfile..."
cp "$CADDYFILE" "$CADDYFILE.backup.$(date +%Y%m%d_%H%M%S)"
echo "2. Removing containers..."
docker stop lgr_wordpress_leadsgrowrevenue lgr_mariadb_recover 2>/dev/null || true
docker rm lgr_wordpress_leadsgrowrevenue lgr_mariadb_recover 2>/dev/null || true
echo "3. Removing Caddyfile entries..."
sed -i '/leadsgrowrevenue\.com {/,/^}/d' "$CADDYFILE"
sed -i '/www\.leadsgrowrevenue\.com {/,/^}/d' "$CADDYFILE"
sed -i '/staging\.leadsgrowrevenue\.com {/,/^}/d' "$CADDYFILE"
echo "4. Reloading Caddy..."
docker exec ssb_caddy caddy reload --config /etc/caddy/Caddyfile
echo "✓ Cleanup complete!"
