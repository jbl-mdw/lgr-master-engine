#!/bin/bash
set -e

echo "=== MASTER SERVICE STARTUP ==="

# 1. Create required networks
echo "Creating Docker networks..."
docker network create southsuburbs_web 2>/dev/null || true
docker network create lgr_network 2>/dev/null || true
docker network create automation_bridge 2>/dev/null || true
docker network create public_gateway 2>/dev/null || true
docker network create shared_network 2>/dev/null || true
docker network create grant_engine_net 2>/dev/null || true

# 2. Start lgr-services stack (MariaDB, WordPress, EspoCRM)
echo "Starting lgr-services..."
cd /mnt/HC_Volume_104274212/lgr-services
docker compose up -d

# 3. Start Caddy
echo "Starting Caddy..."
docker run -d --name ssb_caddy --network southsuburbs_web --network public_gateway \
  -p 80:80 -p 443:443 \
  -v /mnt/HC_Volume_104274212/docker/volumes/southsuburbs_caddy_config/_data:/config \
  -v /mnt/HC_Volume_104274212/docker/volumes/southsuburbs_caddy_data/_data:/data \
  caddy:latest caddy run --config /config/Caddyfile 2>/dev/null || echo "Caddy already running"

# 4. Start South Suburbs Best (Directus + PostgreSQL)
echo "Starting South Suburbs Best..."
cd /opt/southsuburbs
docker compose up -d

# 5. Start N8N
echo "Starting N8N..."
cd /opt/shared-services/n8n
docker compose up -d

# 6. Start Grant Engine (LGR Data Engine with Flowise)
echo "Starting Grant Engine..."
cd /opt/southsuburbs/grant-engine
docker compose up -d

# 7. Start PM2 services (SSB Frontend)
echo "Starting PM2 services..."
pm2 resurrect

echo "=== STARTUP COMPLETE ==="
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
echo ""
pm2 list
