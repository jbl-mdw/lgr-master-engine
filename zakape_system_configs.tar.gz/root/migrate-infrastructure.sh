#!/bin/bash
set -e

echo "JBL Empire Infrastructure Migration"
echo "===================================="

# Create networks
echo "Creating core networks..."
docker network create automation_bridge 2>/dev/null || echo "automation_bridge exists"
docker network create public_gateway 2>/dev/null || echo "public_gateway exists"

# Fix N8N
echo "Connecting N8N to proper networks..."
docker network connect automation_bridge n8n 2>/dev/null || echo "N8N already on automation_bridge"
docker network connect public_gateway n8n 2>/dev/null || echo "N8N already on public_gateway"

# Deploy Flowise
echo "Deploying Flowise..."
docker stop flowise 2>/dev/null || true
docker rm flowise 2>/dev/null || true

docker run -d \
  --name flowise \
  --restart unless-stopped \
  -v ~/stacks/flowise/data/.flowise:/root/.flowise \
  --network automation_bridge \
  -e PORT=3000 \
  flowiseai/flowise:latest

docker network connect public_gateway flowise

# Fix Caddy
echo "Connecting Caddy to proper networks..."
docker network connect automation_bridge ssb_caddy 2>/dev/null || echo "Caddy already on automation_bridge"
docker network connect public_gateway ssb_caddy 2>/dev/null || echo "Caddy already on public_gateway"

# Cleanup
echo "Cleaning up..."
pm2 stop ssb_frontend 2>/dev/null || true
pm2 delete ssb_frontend 2>/dev/null || true
pm2 save

# Test
echo "Testing connectivity..."
docker exec ssb_caddy wget -q -O- http://n8n:5678 > /dev/null && echo "✓ N8N works" || echo "✗ N8N failed"
docker exec ssb_caddy wget -q -O- http://flowise:3000 > /dev/null && echo "✓ Flowise works" || echo "✗ Flowise failed"

echo "Done! Test: https://ai.leads2scale.com and https://automation.leads2scale.com"
