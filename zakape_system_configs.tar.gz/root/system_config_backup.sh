#!/bin/bash
REPO_DIR="/root/lgr-master-engine"
BACKUP_FILE="$REPO_DIR/zakape_system_configs.tar.gz"
TIMESTAMP=$(date +"%Y-%m-%d")

# Move to root so tar paths are cleaner
cd /

# 1. Compress with the exclude flag at the START
tar -czf $BACKUP_FILE \
    --exclude="root/lgr-master-engine" \
    etc \
    root/*.sh \
    root/*.yml \
    var/spool/cron/crontabs

# 2. Push to GitHub
cd $REPO_DIR
git add zakape_system_configs.tar.gz
git commit -m "Full System Config Backup (Fixed): $TIMESTAMP"
git push origin main
