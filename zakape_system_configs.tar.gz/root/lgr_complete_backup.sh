#!/bin/bash
REPO_DIR="/root/lgr-master-engine"
TIMESTAMP=$(date +"%Y-%m-%d")

# 1. Master Engine (Postgres)
docker exec -e PGPASSWORD='directus_password' lgr_engine_postgres pg_dump -U directus directus | gzip > $REPO_DIR/lgr_engine_1_16_restored.sql.gz

# 2. SSB & Klirtrak (Using Internal Variables)
docker exec ssb_postgres sh -c 'PGPASSWORD=$POSTGRES_PASSWORD pg_dump -U $POSTGRES_USER $POSTGRES_DB' | gzip > $REPO_DIR/ssb_backup.sql.gz

# 3. LGR WordPress (Using Internal Variables)
docker exec lgr_mariadb sh -c 'mysqldump -u root -p"$MYSQL_ROOT_PASSWORD" --all-databases' | gzip > $REPO_DIR/lgr_wordpress_prod.sql.gz

# 4. Leads2Scale (Using Internal Variables)
docker exec leads2scale_mariadb sh -c 'mysqldump -u root -p"$MYSQL_ROOT_PASSWORD" --all-databases' | gzip > $REPO_DIR/leads2scale_prod.sql.gz

# 5. SYSTEM CONFIGS
cd /
tar -czf $REPO_DIR/zakape_system_configs.tar.gz \
    --exclude="root/lgr-master-engine" \
    etc root/*.sh root/*.yml var/spool/cron/crontabs

# 6. PUSH
cd $REPO_DIR
git add .
git commit -m "Verified Compressed Backup: $TIMESTAMP"
git push origin main
