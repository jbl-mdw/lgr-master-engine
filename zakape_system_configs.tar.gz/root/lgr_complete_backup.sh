#!/bin/bash
REPO_DIR="/root/lgr-master-engine"
TIMESTAMP=$(date +"%Y-%m-%d")

# 1. Master Engine (Postgres)
docker exec -e PGPASSWORD='directus_password' lgr_engine_postgres pg_dump -U directus directus > $REPO_DIR/lgr_engine_1_16_restored.sql

# 2. SSB & Klirtrak (Postgres)
docker exec -e PGPASSWORD='directus_password' ssb_postgres pg_dump -U ssb_user ssb_db > $REPO_DIR/ssb_backup.sql

# 3. WordPress Production (MariaDB)
docker exec lgr_mariadb mysqldump -u root -p'WmmpQhYYFkHzM0B7kDxjf9zvjC0=' lgr_wordpress > $REPO_DIR/lgr_wordpress_prod.sql

# 4. Leads2Scale (MariaDB)
docker exec leads2scale_mariadb mysqldump -u root -p'WmmpQhYYFkHzM0B7kDxjf9zvjC0=' leads2scale_wp > $REPO_DIR/leads2scale_prod.sql

# 5. SYSTEM CONFIGS
cd /
tar -czf $REPO_DIR/zakape_system_configs.tar.gz \
    --exclude="root/lgr-master-engine" \
    etc root/*.sh root/*.yml var/spool/cron/crontabs

# 6. PUSH TO GITHUB
cd $REPO_DIR
git add .
git commit -m "Full Verified Backup: $TIMESTAMP"
git push origin main
