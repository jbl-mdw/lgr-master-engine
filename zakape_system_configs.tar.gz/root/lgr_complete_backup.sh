#!/bin/bash
REPO_DIR="/root/lgr-master-engine"
TIMESTAMP=$(date +"%Y-%m-%d")

# --- 1. DATABASE DUMPS (THE DATA) ---
# Master Engine (Directus)
docker exec lgr_engine_postgres pg_dump -U directus directus > $REPO_DIR/lgr_engine_1_16_restored.sql

# SSB & Klirtrak (Postgres)
docker exec ssb_postgres pg_dump -U ssb_user ssb_db > $REPO_DIR/ssb_backup.sql

# WordPress Production (MariaDB)
docker exec lgr_mariadb mysqldump -u root -p'REPLACE_WITH_YOUR_DB_PASS' lgr_wordpress > $REPO_DIR/lgr_wordpress_prod.sql
docker exec leads2scale_mariadb mysqldump -u root -p'REPLACE_WITH_YOUR_DB_PASS' leads2scale_wp > $REPO_DIR/leads2scale_prod.sql

# --- 2. SYSTEM CONFIGS (THE BRAINS) ---
cd /
tar -czf $REPO_DIR/zakape_system_configs.tar.gz \
    --exclude="root/lgr-master-engine" \
    etc root/*.sh root/*.yml var/spool/cron/crontabs

# --- 3. PUSH TO GITHUB ---
cd $REPO_DIR
git add .
git commit -m "Full System & DB Snapshot: $TIMESTAMP"
git push origin main
